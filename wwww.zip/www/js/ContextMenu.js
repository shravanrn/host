(function () {
    var contextDiv = "__cordovaappharness_div_contextMenu";

    /* global document */
    var metadataTag = document.getElementsByTagName("head")[0];

    if(!metadataTag) {
        // Fallback to the body
        metadataTag = document.getElementsByTagName("body")[0];
    }

    if(!metadataTag) {
        alert("No head or body tag aborting. Unable to inject size information and context menu");
        return;
    }

    // Inject the viewport metadata to fix the zoom
    metadataTag.innerHTML += "<meta name='viewport' content='initial-scale=1, user-scalable=no'>";

    var elementTag = document.getElementsByTagName("body")[0];

    if(!elementTag) {
        // Fallback to the head
        elementTag = document.getElementsByTagName("head")[0];
    }

    // Inject the html of the context menu. This is setup by the page that loads this script.
    /* global __cordovaAppHarnessInjected */
    elementTag.innerHTML += __cordovaAppHarnessInjected.contextHTMLContent;

    // Setup the listeners to toggle the context menu
    document.addEventListener("touchmove", function (event) {
        if(event.touches.length >= 3) {
            document.getElementById(contextDiv).style.display = "inline";
        }
    }, false);

    document.getElementById(contextDiv).onclick = function() {
        document.getElementById(contextDiv).style.display = "none";
    };
})();


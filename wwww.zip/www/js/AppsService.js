(function() {
    "use strict";
    /* global myApp */
    myApp.factory("AppsService", [ "ResourcesLoader", "INSTALL_DIRECTORY", "TEMP_DIRECTORY", "APPS_JSON", "$window", function(ResourcesLoader, INSTALL_DIRECTORY, TEMP_DIRECTORY, APPS_JSON, $window) {

        /* global DOMParser */
        //DOMParser implementation for unsupported mime times
        (function(DOMParser) {
            var DOMParser_proto = DOMParser.prototype
              , real_parseFromString = DOMParser_proto.parseFromString;

            // Firefox/Opera/IE throw errors on unsupported types
            try {
                // WebKit returns null on unsupported types
                if ((new DOMParser).parseFromString("", "text/html")) {
                    // text/html parsing is natively supported
                    return;
                }
            } catch (ex) {}

            DOMParser_proto.parseFromString = function(markup, type) {
                if (/^\s*text\/html\s*(?:;|$)/i.test(type)) {
                    var doc = document.implementation.createHTMLDocument("")
                      , doc_elt = doc.documentElement
                      , first_elt;

                    doc_elt.innerHTML = markup;
                    first_elt = doc_elt.firstElementChild;

                    if (doc_elt.childElementCount === 1
                        && first_elt.localName.toLowerCase() === "html") {
                        doc.replaceChild(first_elt, doc_elt);
                    }

                    return doc;
                } else {
                    return real_parseFromString.apply(this, arguments);
                }
            };
        }(DOMParser));

        function addNewAppFromUrl(appName, appUrl) {
            var fileName = TEMP_DIRECTORY + appName + ".zip";
            var _fullFilePath;

            return ResourcesLoader.downloadFromUrl(appUrl, fileName)
            .then(function(fullFilePath){
                _fullFilePath = fullFilePath;
                return ResourcesLoader.ensureDirectoryExists(INSTALL_DIRECTORY + appName);
            })
            .then(function(directoryPath){
                return extractZipToDirectory(_fullFilePath, directoryPath);
            })
            .then(function(){
                return injectContextMenuIntoApp(appName);
            })
            .then(function(){
                return registerApp(appName, "urlToZip", appUrl);
            });
        }

        function extractZipToDirectory(fileName, outputDirectory){
            var deferred = Q.defer();

            var onZipDone = function(returnCode) {
                if(returnCode !== 0) {
                    deferred.reject(new Error("Something went wrong during the unzipping of: " + fileName));
                } else {
                    deferred.resolve();
                }
            };

            /* global zip */
            zip.unzip(fileName, outputDirectory, onZipDone);
            return deferred.promise;
        }

        function registerApp(appName, appSource, appUrl) {
            return ResourcesLoader.readJSONFileContents(APPS_JSON)
            .then(function(result){
                result.installedApps = result.installedApps || [];
                result.installedApps.push({
                    "Name" :  appName,
                    "Source" : appSource,
                    "Url" : appUrl
                });
                return ResourcesLoader.writeJSONFileContents(APPS_JSON, result);
            });
        }

        function getAbsoluteUrl(relativeUrl) {
            // Can't use $document from angularJS as it does not provie the create constructor
            /* global document */
            var a = document.createElement("a");
            a.href = relativeUrl;
            return a.href;
        }

        function getAppStartPageFromAppLocation(appLocation) {
            appLocation += (appLocation.substring(appLocation.length - 1) === "/") ? "" : "/";
            var startLocation = appLocation + "www/index.html";
            return startLocation;
        }

        function promiseXHRGet(location) {
            var deferred = Q.defer();

            var xhr = new $window.XMLHttpRequest();
            xhr.onreadystatechange=function()
            {
                if (xhr.readyState==4) {
                    if(xhr.status==200) {
                        deferred.resolve(xhr);
                    } else {
                        deferred.reject(new Error("Could not retrieve " + location + " - Got status: " + xhr.status));
                    }
                }
            };
            // retrieve the context menu
            xhr.open("GET", location, true);
            xhr.send();
            return deferred.promise;
        }

        function injectContextMenuIntoApp(appName) {
            var startLocation, appHtmlString;
            alert("injecting to app " + appName);
            return ResourcesLoader.getFullFilePath(INSTALL_DIRECTORY + appName)
            .then(function(appLocation) {
                startLocation = getAppStartPageFromAppLocation(appLocation);
                alert("file " + startLocation);
                return ResourcesLoader.readFileContents(startLocation);
            })
            .then(function(_appHtmlString){
                appHtmlString = _appHtmlString;
                alert("contents: \n" + appHtmlString);
                return promiseXHRGet("contextMenu.html");
            })
            .then(function(xhrContextMenu) {
                var contextHtmlString = xhrContextMenu.responseText;
                var modifiedContents = insertAfterBody(appHtmlString, contextHtmlString);
                alert("contents: \n" + modifiedContents);
                return ResourcesLoader.writeFileContents(startLocation, modifiedContents);
            });
        }

        function insertAfterBody(htmlString, injectedString) {
            var parser = new DOMParser();
            var htmlDoc = parser.parseFromString(htmlString,"text/html");
            htmlDoc.body.innerHTML = injectedString + htmlDoc.head.innerHTML;
            /* global XMLSerializer */
            var serializer = new XMLSerializer();
            var serializedContents = serializer.serializeToString(htmlDoc);
            return serializedContents;
        }

        return {
            //return promise with the array of apps
            getAppsList : function() {
                return ResourcesLoader.ensureDirectoryExists(APPS_JSON)
                .then(function() {
                    return ResourcesLoader.readJSONFileContents(APPS_JSON);
                })
                .then(function(result){
                    result.installedApps = result.installedApps || [];
                    var newAppsList = [];

                    for(var i = 0; i < result.installedApps.length; i++){
                        newAppsList.push(result.installedApps[i].Name);
                    }

                    return newAppsList;
                });
            },

            launchApp : function(appName) {
                return ResourcesLoader.getFullFilePath(INSTALL_DIRECTORY + appName)
                .then(function(appLocation) {
                    // var startLocation = getAppStartPageFromAppLocation(appLocation);
                    // var ref = $window.open(startLocation, "_blank" ,"location=no");

                    // var onLoadStop = function(){
                    //     var contextHTMLUrl = getAbsoluteUrl("contextMenu.html");
                    //     var xhr = new $window.XMLHttpRequest();
                    //     xhr.onreadystatechange=function()
                    //     {
                    //         if (xhr.readyState==4 && xhr.status==200)
                    //         {
                    //             var stringifiedHtml = xhr.responseText.replace(/\n/g, "").replace(/'/g, "\'");
                    //             var code = "var __cordovaAppHarnessInjected = {};" +
                    //                 "__cordovaAppHarnessInjected.contextHTMLContent = '" + stringifiedHtml + "';";

                    //             // inject the context menu as a global
                    //             ref.executeScript({ "code" : code }, function() {
                    //                 // inject script the controls behaviour of context menu
                    //                 var absoluteUrl = getAbsoluteUrl("js/ContextMenu.js");
                    //                 ref.executeScript({ "file" : absoluteUrl });
                    //             });
                    //         }
                    //     };
                    //     // retrieve the context menu
                    //     xhr.open("GET", contextHTMLUrl, true);
                    //     xhr.send();
                    // };

                    // var onLoadStart = function(event){
                    //     if(event.url === "http://about:blank#MainMenu") {
                    //         ref.close();
                    //         ref.removeEventListener("loadstop", onLoadStop);
                    //         ref.removeEventListener("loadstart", onLoadStart);
                    //     }
                    // };

                    // ref.addEventListener("loadstop", onLoadStop);
                    // ref.addEventListener("loadstart", onLoadStart);
                });
            },

            addAppFromZipUrl : function(appName, appUrl) {
                return this.getAppsList()
                .then(function(appsList){
                    if(appsList.indexOf(appName) !== -1) {
                        throw new Error("An app with this name already exists");
                    }
                    return addNewAppFromUrl(appName, appUrl);
                });
            }
        };
    }]);
})();
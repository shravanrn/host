cordova-app-harness
===================

An App harness for Cordova that can download and run Cordova apps as well as Chrome packaged apps. This enables an edit &amp; refresh workflow. Also enables local development of apps without needing the Android / iOS SDK.

#Building

This app needs the following plugins:
zip - https://github.com/MobileChromeApps/zip